<?php
session_start();
include '../db_connect.php';

$user_id = $_SESSION['user_id'] ?? null;
$cart_items = [];

if ($user_id) {
    $stmt = $conn->prepare("
        SELECT p.id, p.name, p.price, p.description, c.quantity, p.image_path
        FROM cart c
        JOIN products p ON c.product_id = p.id
        WHERE c.user_id = ?
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $cart_items[] = [
            'id' => $row['id'],
            'name' => $row['name'],
            'price' => $row['price'],
            'description' => $row['description'],
            'quantity' => $row['quantity'],
            'image' => '../admin_seller/uploads/product/' . $row['image_path']
        ];
    }
    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Cart Screen - E-Mart</title>
  <link rel="stylesheet" href="cart_screen_styles.css" />
</head>
<body>
  <div class="top-panel">
    <div class="logo">E-Mart</div>
    <div class="right-panel">
      <div class="search-bar">
        <input type="text" placeholder="Search for..." />
      </div>
      <div class="username"><?php echo htmlspecialchars($_SESSION['username'] ?? 'Guest'); ?></div>
      <div class="icons">
        <a href="cart_screen.php"><img src="../assets/images/cart_icon.png" alt="Cart" /></a>
        <form action="../index.html" method="post" style="display: inline-block; margin-left: 10px;">
          <button type="submit" class="logout-btn">Logout</button>
        </form>
      </div>
    </div>
  </div>

  <div class="sidebar">
    <a href="#"><img src="../assets/images/desktop_icon.png" alt="Desktop" /></a>
    <a href="#"><img src="../assets/images/mobile_icon.png" alt="Mobile" /></a>
    <a href="#"><img src="../assets/images/component_icon.png" alt="Component" /></a>
    <a href="#"><img src="../assets/images/peripherals_icon.png" alt="Peripherals" /></a>
    <a href="#"><img src="../assets/images/game_icon.png" alt="Gaming" /></a>
    <a href="#"><img src="../assets/images/others_icon.png" alt="Others" /></a>
  </div>

  <main>
    <div class="cart-left-wrapper">
      <div class="cart-left">
        <div class="cart-navigation">
          <a href="customer_screen.php"><img src="../assets/images/back_icon.png" alt="Back" /></a>
          <h3>My Cart</h3>
        </div>

        <?php if (!empty($cart_items)): ?>
        <form id="cart-form" action="payment_screen.php" method="post">
          <?php foreach ($cart_items as $item): ?>
          <div class="cart-item">
            <input 
              type="checkbox" 
              class="item-checkbox" 
              name="selected_items[]" 
              value="<?= $item['id'] ?>" 
              data-name="<?= htmlspecialchars($item['name']) ?>"
              data-description="<?= htmlspecialchars($item['description']) ?>"
              data-price="<?= $item['price'] ?>" 
              data-quantity="<?= $item['quantity'] ?>" 
              id="item-<?= $item['id'] ?>" 
            />
            <label for="item-<?= $item['id'] ?>">
              <img src="<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>" style="width: 120px; height: 120px;" />
              <div class="item-details">
                <p><strong><?= htmlspecialchars($item['name']) ?></strong></p>
                <p><?= nl2br(htmlspecialchars($item['description'])) ?></p> 
                <p>Price: ₱<?= number_format($item['price'], 2) ?></p>
                <p>Quantity: <input type="number" class="quantity-input" data-id="<?= $item['id'] ?>" value="<?= (int)$item['quantity'] ?>" min="1" /></p>
              </div>
            </label>
            <button type="button" class="remove-btn" data-product-id="<?= $item['id'] ?>">Remove</button>
          </div>
          <?php endforeach; ?>

          <!-- Hidden input to hold JSON of selected checked items -->
          <input type="hidden" name="cart_data" id="cart-data" />

          
        </form>
        <?php else: ?>
          <p>Your cart is empty.</p>
        <?php endif; ?>
      </div>
    </div>

    <div class="cart-right-wrapper">
      <div class="cart-right">
        <h3>My Cart Summary</h3>
        <ul id="summary-list"></ul>
        <div class="total" id="total-price">Total: ₱0.00</div>
        <!-- Checkout button -->
          <button type="submit" form="cart-form" class="checkout">Proceed to Checkout</button>
      </div>
    </div>
  </main>

  <footer>
        <div class="footer-top">
            <p>Stay informed! Get exclusive deals and product updates!</p>
            <div class="footer-subscribe-form">
                <input type="email" placeholder="Enter your email" aria-label="Email address for subscription" />
                <button>Subscribe</button>
            </div>
        </div>

        <div class="footer-bottom">
            <div class="footer-column">
                <p><strong>Help Center</strong></p>
                <p>
                    <img src="../assets/images/instagram_icon.png" class="social-icon" alt="Instagram" />
                    <img src="../assets/images/x_icon.png" class="social-icon" alt="Twitter" />
                    <img src="../assets/images/facebook_icon.png" class="social-icon" alt="Facebook" />
                </p>
            </div>

            <div class="footer-column">
                <p><strong>Support</strong></p>
                <p>FAQs</p>
                <p>Contact Us</p>
                <p>User Manuals</p>
            </div>

            <div class="footer-column">
                <p><strong>Assistance</strong></p>
                <p>Privacy Policy</p>
                <p>Site Map</p>
                <p>Product</p>
            </div>

            <div class="footer-column">
                <p><strong>Get in Touch</strong></p>
                <p><a href="mailto:johnbacolod28@gmail.com">johnbacolod28@gmail.com</a></p>
                <p>+123 456 7890</p>
            </div>
        </div>
    </footer>

  <script>
    function formatMoney(amount) {
      return amount.toLocaleString('en-PH', { style: 'currency', currency: 'PHP' });
    }

    const checkboxes = document.querySelectorAll('.item-checkbox');
    const summaryList = document.getElementById('summary-list');
    const totalPriceEl = document.getElementById('total-price');
    const hiddenCartData = document.getElementById('cart-data');
    const checkoutForm = document.getElementById('cart-form');

    function updateSummary() {
      summaryList.innerHTML = '';
      let total = 0;
      let anyChecked = false;
      let selectedItems = [];

      checkboxes.forEach(cb => {
        if (cb.checked) {
          anyChecked = true;
          const label = cb.nextElementSibling;
          const name = cb.dataset.name;
          const price = parseFloat(cb.dataset.price);
          const quantityInput = label.querySelector('.quantity-input');
          const quantity = parseInt(quantityInput.value);
          const itemTotal = price * quantity;
          total += itemTotal;

          selectedItems.push({
            id: cb.value,
            name,
            description: cb.dataset.description,
            price,
            quantity,
            total: itemTotal,
            image: label.querySelector('img').src
          });

          const li = document.createElement('li');
          li.textContent = `${quantity}x ${name}`;
          const span = document.createElement('span');
          span.textContent = formatMoney(itemTotal);
          li.appendChild(span);
          summaryList.appendChild(li);
        }
      });

      if (!anyChecked) {
        summaryList.innerHTML = '<li>No items selected.</li>';
      }

      totalPriceEl.textContent = `Total: ${formatMoney(total)}`;
      hiddenCartData.value = JSON.stringify({ items: selectedItems, total });
    }

    checkboxes.forEach(cb => cb.addEventListener('change', updateSummary));

    document.querySelectorAll('.quantity-input').forEach(input => {
      input.addEventListener('change', function () {
        const newQuantity = this.value;
        const productId = this.dataset.id;
        const checkbox = this.closest('.cart-item').querySelector('.item-checkbox');
        checkbox.dataset.quantity = newQuantity;
        updateSummary();

        fetch('update_quantity.php', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: 'product_id=' + productId + '&quantity=' + newQuantity
        })
        .then(res => res.text())
        .then(response => {
          if (response.trim() !== 'success') {
            alert('Failed to update quantity.');
          }
        });
      });
    });

    document.querySelectorAll('.remove-btn').forEach(button => {
      button.addEventListener('click', function () {
        const productId = this.dataset.productId;
        if (confirm('Remove this item from your cart?')) {
          fetch('remove_from_cart.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'product_id=' + productId
          })
          .then(res => res.text())
          .then(response => {
            if (response.trim() === 'success') {
              this.closest('.cart-item').remove();
              updateSummary();
            } else {
              alert('Failed to remove item.');
            }
          });
        }
      });
    });

    checkoutForm.addEventListener('submit', function (e) {
      if (hiddenCartData.value.trim() === '' || hiddenCartData.value === '{}') {
        e.preventDefault();
        alert('Please select at least one item to proceed to checkout.');
      }
    });

    // Initialize summary on page load
    updateSummary();
  </script>
</body>
</html>
