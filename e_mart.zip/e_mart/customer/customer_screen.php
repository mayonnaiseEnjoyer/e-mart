<?php
session_start();
include '../db_connect.php'; // Adjust path if needed

// Fetch all products from the database
$sql = "SELECT * FROM products ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Customer Screen - E-Mart</title>
  <link rel="stylesheet" href="customer_screen_styles.css" />
</head>

<body>
  <!-- Top Panel -->
  <div class="top-panel">
    <div class="logo">E-Mart</div>
    <div class="right-panel">
      <div class="search-bar">
        <input type="text" placeholder="Search for..." />
      </div>
      <div class="username">
        <?php echo htmlspecialchars($_SESSION['username'] ?? 'Guest'); ?>
      </div>
      <div class="icons">
        <a href="cart_screen.php">
          <img src="../assets/images/cart_icon.png" alt="Cart" />
        </a>
        <form action="../index.html" method="post" style="display: inline-block; margin-left: 10px;">
          <button type="submit" class="logout-btn">Logout</button>
        </form>
      </div>
    </div>
  </div>

  <!-- Main Area -->
  <div class="main">
    <!-- Sidebar -->
    <div class="sidebar">
      <a href="#"><img src="../assets/images/desktop_icon.png" alt="Desktop" /></a>
      <a href="#"><img src="../assets/images/mobile_icon.png" alt="Mobile" /></a>
      <a href="#"><img src="../assets/images/component_icon.png" alt="Component" /></a>
      <a href="#"><img src="../assets/images/peripherals_icon.png" alt="Peripherals" /></a>
      <a href="#"><img src="../assets/images/game_icon.png" alt="Gaming" /></a>
      <a href="#"><img src="../assets/images/others_icon.png" alt="Others" /></a>
    </div>

    <!-- Content Area -->
    <div class="container">
      <div class="content-scroll">
        <h1 class="main-title">E-Mart</h1>

        <!-- Feature Highlights -->
        <div class="category-section">
          <div class="category-card">
            <h2>Top Sellers</h2>
            <p class="view-all">View all</p>
            <button class="explore-btn">Explore</button>
          </div>
          <div class="category-card">
            <h2>New Arrivals</h2>
            <p class="view-all">View all</p>
            <button class="explore-btn">Explore</button>
          </div>
          <div class="category-card">
            <h2>On Sale</h2>
            <p class="view-all">View all</p>
            <button class="explore-btn">Explore</button>
          </div>
        </div>

        <!-- Product List -->
        <div class="product-list">
          <?php if ($result && $result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
              <?php
                $imagePath = "../admin_seller/uploads/product/" . htmlspecialchars($row['image_path']);
              ?>
              <div class="product-item">
                <img src="<?php echo $imagePath; ?>" alt="Product" class="product-image"
                     onerror="this.src='../assets/images/placeholder.png';" />
                <div class="product-info">
                  <h3><?php echo htmlspecialchars($row['name']); ?></h3>
                  <p style="font-size: 13px; color: #ccc;">
                    <?php echo htmlspecialchars($row['description']); ?>
                  </p>
                  <div style="height: 15px;"></div>
                  <p>Stock: <?php echo (int)$row['stock']; ?></p>
                  <p>Price: ₱<?php echo number_format($row['price'], 2); ?></p>
                </div>
                <a class="view-button" href="item_screen.php?id=<?php echo $row['id']; ?>">View</a>
              </div>
            <?php endwhile; ?>
          <?php else: ?>
            <p>No products available.</p>
          <?php endif; ?>
        </div>

      </div>
    </div>
  </div>
</body>

</html>
