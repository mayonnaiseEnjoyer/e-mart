<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['username'])) {
    header('Location: login.php');
    exit();
}

$username = htmlspecialchars($_SESSION['username']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Payment Success</title>
    <link rel="stylesheet" href="payment_success_style.css" />
</head>
<body>
    <div class="container">
        <div class="message-box">
            <h1>Thank you for your purchase, <?= $username ?>!</h1>
            <p>Your order has been placed successfully.</p>
            <button onclick="window.location.href='cart_screen.php'" class="back-button">Back to Cart</button>
        </div>
    </div>
</body>
</html>
