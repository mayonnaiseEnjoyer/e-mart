<?php
session_start();
include '../db_connect.php';

$product_id = $_GET['id'] ?? null;

if (!$product_id) {
    echo "Product ID missing.";
    exit;
}

$stmt = $conn->prepare("SELECT name, description, price, stock, image_path FROM products WHERE id = ?");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows !== 1) {
    echo "Product not found.";
    exit;
}

$stmt->bind_result($name, $description, $price, $stock, $image_path);
$stmt->fetch();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?php echo htmlspecialchars($name); ?> - E-Mart</title>
  <link rel="stylesheet" href="item_screen_style.css" />
</head>
<body>
  <div class="item-screen">
    <a href="customer_screen.php">
      <img src="../assets/images/back_icon.png" alt="Back" class="back-icon" />
    </a>

    <div class="product-details">
      <div class="left">
        <div class="image-wrapper">
          <img src="<?php echo '../admin_seller/uploads/product/' . htmlspecialchars($image_path); ?>" 
               alt="<?php echo htmlspecialchars($name); ?>" 
               class="main-product-image"
               onerror="this.src='../assets/images/placeholder.png';" />
        </div>
      </div>

      <div class="right">
        <h1><?php echo htmlspecialchars($name); ?></h1>
        <p><?php echo nl2br(htmlspecialchars($description)); ?></p>
        <p><strong>Stock:</strong> <?php echo intval($stock); ?></p>
        <h2>₱<?php echo number_format($price, 2); ?></h2>

        <form id="add-to-cart-form">
          <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product_id); ?>" />
          <label for="quantity">Qty:</label>
          <input type="number" name="quantity" id="quantity" value="1" min="1" max="<?php echo intval($stock); ?>" required />
          <button type="submit" class="add-to-cart">Add to Cart</button>
        </form>

        <p id="message" style="color: green; font-weight: bold; display: none;">Added to cart!</p>
      </div>
    </div>
  </div>

<script>
document.getElementById('add-to-cart-form').addEventListener('submit', function(e) {
  e.preventDefault();
  const formData = new FormData(this);

  fetch('add_to_cart.php', {
    method: 'POST',
    body: formData,
  }).then(response => response.json())
    .then(data => {
      const msg = document.getElementById('message');
      if (data.success) {
        msg.style.display = 'block';
        setTimeout(() => { msg.style.display = 'none'; }, 2000);
      } else {
        alert(data.error || 'Error adding to cart');
      }
    })
    .catch(() => alert('Network error'));
});
</script>

</body>
</html>
