<?php
session_start();
require 'db_connect.php'; // Your DB connection

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Get posted cart data (JSON string)
$cart_data_json = $_POST['cart_data'] ?? null;
if (!$cart_data_json) {
    die("No cart data received.");
}

$cart_data = json_decode($cart_data_json, true);
if (!$cart_data || !isset($cart_data['items'])) {
    die("Invalid cart data.");
}

// Start transaction
$conn->begin_transaction();

try {
    // Insert transaction record (assuming you have a 'transactions' table)
    // You might want to generate a transaction ID or use auto_increment
    $stmt = $conn->prepare("INSERT INTO transactions (user_id, total_amount, transaction_date) VALUES (?, ?, NOW())");

    $subtotal = 0;
    foreach ($cart_data['items'] as $item) {
        $subtotal += $item['price'] * $item['quantity'];
    }
    $shipping_cost = 100.00;
    $total = $subtotal + $shipping_cost;

    $stmt->bind_param("id", $user_id, $total);
    $stmt->execute();
    $transaction_id = $stmt->insert_id; // get inserted transaction id
    $stmt->close();

    // Update stock for each item and insert transaction details
    foreach ($cart_data['items'] as $item) {
        $product_id = $item['id'];      // Assuming item has 'id'
        $quantity = $item['quantity'];

        // Decrease stock for product
        $update_stock = $conn->prepare("UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?");
        $update_stock->bind_param("iii", $quantity, $product_id, $quantity);
        $update_stock->execute();

        if ($update_stock->affected_rows == 0) {
            // Stock not enough or product not found
            throw new Exception("Not enough stock for product ID $product_id");
        }
        $update_stock->close();

        // Insert transaction details
        $insert_details = $conn->prepare("INSERT INTO transaction_details (transaction_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
        $price = $item['price'];
        $insert_details->bind_param("iiid", $transaction_id, $product_id, $quantity, $price);
        $insert_details->execute();
        $insert_details->close();
    }

    // Commit transaction
    $conn->commit();

    // Optionally clear cart here (depends on how you store the cart)
    // e.g. unset($_SESSION['cart']) or delete cart items in DB

    // Redirect to success page
    header('Location: payment_success.php');
    exit();

} catch (Exception $e) {
    $conn->rollback();
    die("Payment failed: " . $e->getMessage());
}
?>
