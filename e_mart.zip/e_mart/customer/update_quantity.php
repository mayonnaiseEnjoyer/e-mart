<?php
session_start();
include '../db_connect.php';

// Check if user is logged in and POST data is set
if (!isset($_SESSION['user_id'], $_POST['product_id'], $_POST['quantity'])) {
    echo 'error';
    exit;
}

$user_id = $_SESSION['user_id'];
$product_id = (int)$_POST['product_id'];
$quantity = (int)$_POST['quantity'];

// Validate quantity (must be at least 1)
if ($quantity < 1) {
    echo 'error';
    exit;
}

// Update quantity in cart for this user and product
$stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?");
$stmt->bind_param("iii", $quantity, $user_id, $product_id);

if ($stmt->execute()) {
    echo 'success';
} else {
    echo 'error';
}

$stmt->close();
$conn->close();
