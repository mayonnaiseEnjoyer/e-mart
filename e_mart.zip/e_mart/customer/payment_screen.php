<?php
session_start();
include '../db_connect.php';

// Handle payment form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['pay_now'])) {
        $cart_data = json_decode($_POST['cart_data'], true);
        $payment_method = $_POST['payment_method'] ?? null;

        // Validate cart contents
        if (!$cart_data || !isset($cart_data['items']) || empty($cart_data['items'])) {
            die("Cart is empty. Please add items to proceed.");
        }

        // Validate payment method
        if (!$payment_method) {
            die("Please select a payment method.");
        }

        $user_id = $_SESSION['user_id'] ?? null;
        if (!$user_id) {
            die("User not logged in.");
        }

        // Begin database transaction
        $conn->begin_transaction();

        try {
            // Process each cart item
            // var_dump($cart_data); // Optional debug

            foreach ($cart_data['items'] as $item) {
                $product_id = (int)$item['id'];  
                $quantity = (int)$item['quantity']; 

                $stmt = $conn->prepare("SELECT stock, seller_id, price FROM products WHERE id = ?");
                $stmt->bind_param("i", $product_id);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows === 0) {
                    throw new Exception("Product ID $product_id not found.");
                }

                $product = $result->fetch_assoc();
                $stmt->close();

                $seller_id = $product['seller_id'];

                if ($product['stock'] < $quantity) {
                    throw new Exception("Not enough stock for product ID $product_id.");
                }

                $new_stock = $product['stock'] - $quantity;

                $update = $conn->prepare("UPDATE products SET stock = ? WHERE id = ?");
                $update->bind_param("ii", $new_stock, $product_id);
                $update->execute();
                $update->close();

                $del = $conn->prepare("DELETE FROM cart WHERE user_id = ? AND product_id = ?");
                $del->bind_param("ii", $user_id, $product_id);
                $del->execute();
                $del->close();

                $total_price = $product['price'] * $quantity;
                $now = date('Y-m-d H:i:s');

                $insert = $conn->prepare("
                    INSERT INTO transaction_history 
                    (user_id, seller_id, product_id, quantity, total_price, payment_method, transaction_date)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $insert->bind_param("iiiidss", $user_id, $seller_id, $product_id, $quantity, $total_price, $payment_method, $now);
                $insert->execute();
                $insert->close();
            }

            // Commit all DB changes
            $conn->commit();

            // Clear cart session after successful payment
            unset($_SESSION['cart_data']);

            // Redirect to success page
            header("Location: payment_success.php");
            exit();

        } catch (Exception $e) {
            // Roll back changes if any failure occurs
            $conn->rollback();
            die("Payment failed: " . $e->getMessage());
        }
    }

    // Save cart_data into session if present in POST
    if (isset($_POST['cart_data'])) {
        $_SESSION['cart_data'] = $_POST['cart_data'];
    }
}

// Retrieve cart data from session for display
$cart_data_json = $_SESSION['cart_data'] ?? null;
$cart_data = null;
if ($cart_data_json) {
    $cart_data = json_decode($cart_data_json, true);
}

$shipping_cost = 100.00;
$subtotal = 0;
if ($cart_data && isset($cart_data['items']) && is_array($cart_data['items'])) {
    foreach ($cart_data['items'] as $item) {
        $price = isset($item['price']) ? (float)$item['price'] : 0;
        $quantity = isset($item['quantity']) ? (int)$item['quantity'] : 0;
        $subtotal += $price * $quantity;
    }
}
$total = $subtotal + $shipping_cost;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Payment Screen - E-Mart</title>
    <link rel="stylesheet" href="payment_screen_style.css" />
</head>
<body>

<div class="container">
    <header class="header">
        <div class="header-left">
            <button class="back-button" aria-label="Go back to previous page" onclick="window.location.href='cart_screen.php'">
                <img src="../assets/images/back_icon.png" alt="Back" />
            </button>
            <div class="header-text">
                <h1>Cart</h1>
                <p class="store-name">E-Mart Store</p>
            </div>
        </div>
    </header>

    <section class="delivery-options" tabindex="0" role="button" aria-label="Enter delivery address">
        <img src="../assets/images/delivery_icon.png" alt="" class="delivery-icon" />
        <div class="delivery-text">
            <strong>Fast delivery available</strong>
            <span>Enter delivery address</span>
        </div>
        <img src="../assets/images/forward_icon.png" alt="" class="forward-icon" />
    </section>

    <section class="selected-products">
        <h2>Selected Products</h2>

        <?php if ($cart_data && !empty($cart_data['items'])): ?>
            <?php foreach ($cart_data['items'] as $item): ?>
                <div class="product-item">
                    <img src="<?= htmlspecialchars($item['image'] ?? '../assets/images/placeholder.png') ?>" 
                         alt="<?= htmlspecialchars($item['name'] ?? 'Product image') ?>" 
                         class="product-image" 
                         onerror="this.onerror=null;this.src='../assets/images/placeholder.png';" />
                    <div class="product-details">
                        <p class="product-qty"><?= (int)$item['quantity'] ?>x <?= htmlspecialchars($item['name'] ?? '') ?></p>
                        <p class="product-description"><?= nl2br(htmlspecialchars($item['description'] ?? 'No description')) ?></p>
                        <p class="product-price">₱<?= number_format(((float)($item['price'] ?? 0)) * (int)$item['quantity'], 2) ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No products selected. Please go back to the <a href="cart_screen.php">cart</a>.</p>
        <?php endif; ?>

        <button class="add-more" onclick="window.location.href='cart_screen.php'">
            <span class="plus">+</span> Add more items
        </button>
    </section>

    <form method="POST" id="paymentForm">
        <input type="hidden" name="cart_data" value='<?= htmlspecialchars(json_encode($cart_data ?? [])) ?>'>
        <section class="summary">

            <div class="left-summary">
                <h3><strong>Payment Options</strong></h3>

                <label class="payment-option">
                    <input type="radio" name="payment_method" value="gcash" required />
                    <img src="../assets/images/gcash_icon.png" alt="Gcash" />
                </label>

                <label class="payment-option">
                    <input type="radio" name="payment_method" value="paypal" required />
                    <img src="../assets/images/paypal_icon.png" alt="Paypal" />
                </label>
            </div>

            <div class="right-summary">
                <h3>Order Summary</h3>
                <p>Subtotal: ₱<?= number_format($subtotal, 2) ?></p>
                <p>Shipping: ₱<?= number_format($shipping_cost, 2) ?></p>
                <p><strong>Total: ₱<?= number_format($total, 2) ?></strong></p>
                <button type="submit" class="pay-button" name="pay_now">Pay Now</button>
            </div>
        </section>
    </form>
</div>

<footer>
    <div class="footer-top">
        <p>Stay informed! Get exclusive deals and product updates!</p>
        <div class="footer-subscribe-form">
            <input type="email" placeholder="Enter your email" aria-label="Email address for subscription" />
            <button>Subscribe</button>
        </div>
    </div>

    <div class="footer-bottom">
        <div class="footer-column">
            <p><strong>Help Center</strong></p>
            <p>
                <img src="../assets/images/instagram_icon.png" class="social-icon" alt="Instagram" />
                <img src="../assets/images/x_icon.png" class="social-icon" alt="Twitter" />
                <img src="../assets/images/facebook_icon.png" class="social-icon" alt="Facebook" />
            </p>
        </div>

        <div class="footer-column">
            <p><strong>Support</strong></p>
            <p>FAQs</p>
            <p>Contact Us</p>
            <p>User Manuals</p>
        </div>

        <div class="footer-column">
            <p><strong>Assistance</strong></p>
            <p>Privacy Policy</p>
            <p>Site Map</p>
            <p>Product</p>
        </div>

        <div class="footer-column">
            <p><strong>Get in Touch</strong></p>
            <p><a href="mailto:johnbacolod28@gmail.com">johnbacolod28@gmail.com</a></p>
            <p>+123 456 7890</p>
        </div>
    </div>
</footer>

</body>
</html>
