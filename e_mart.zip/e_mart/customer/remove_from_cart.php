<?php
session_start();
include '../db_connect.php';

$user_id = $_SESSION['user_id'] ?? null;
$product_id = $_POST['product_id'] ?? null;

if ($user_id && $product_id) {
    $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ? AND product_id = ?");
    $stmt->bind_param("ii", $user_id, $product_id);
    $success = $stmt->execute();
    $stmt->close();
    echo $success ? 'success' : 'error';
} else {
    echo 'error';
}

$conn->close();
?>
