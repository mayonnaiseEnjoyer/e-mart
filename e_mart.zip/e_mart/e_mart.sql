-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 03, 2025 at 02:37 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e_mart`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `image_path` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `category`, `description`, `price`, `seller_id`, `stock`, `created_at`, `image_path`, `image`) VALUES
(16, 'ASUS ROG GL552', 'desktop', 'Intel i7-6700HQ CPU, GTX 960M GPU (2-4GB), 15.6\" Full HD screen, up to 16GB RAM, SSD + HDD storage options', 69995.00, 1, 8, '2025-06-02 19:40:26', 'prod_683dfe2ad828a7.88723304.png', NULL),
(17, 'Nintendo Switch', 'gaming', '6.2\" LCD, 720p, 32GB storage, up to 1080p HDMI, detachable Joy-Cons, 4.5–9 hrs battery', 31990.00, 1, 9, '2025-06-02 19:41:32', 'prod_683dfe6caabe60.91315324.png', NULL),
(18, 'HP Envy laptop', 'desktop', 'Intel Core i5 processor, SSD storage, Full HD or 4K displays, premium metal build\r\n', 54845.00, 1, 5, '2025-06-02 19:42:45', 'prod_683dfeb5bf0350.32273408.png', NULL),
(19, 'Seagate Barracuda 3.5\" HDD', 'component', 'SATA III (6 Gb/s), 500GB,  7200 RPM', 2995.00, 1, 13, '2025-06-02 19:44:46', 'prod_683dff2e7983d2.25330522.png', NULL),
(20, 'Samsung 860 EVO', 'component', '2.5\" SATA III SSDs using NAND flash', 3195.00, 1, 12, '2025-06-02 19:45:51', 'prod_683dff6f3d8a10.05650382.png', NULL),
(21, 'iPhone XR', 'mobile', '6.1\" Liquid Retina HD (LCD), 828 x 1792 pixels, True Tone, Apple A12 Bionic chip, 3+125GB', 3195.00, 1, 8, '2025-06-02 19:47:32', 'prod_683dffd4c359a5.42706525.png', NULL),
(22, 'Xbox 360', 'gaming', '3.2 GHz PowerPC Tri-Core CPU, 512MB RAM, 500MHz ATI Xenos GPU, up to 500GB HDD, 480p–1080p video output, Wi-Fi, Ethernet, USB 2.0 ports', 10773.00, 1, 4, '2025-06-02 19:49:03', 'prod_683e002f38bed9.76270987.png', NULL),
(23, 'JBL T450BT', 'peripheral', 'on-ear headphones with 32mm drivers, Bluetooth 4.0, 20Hz–20kHz range', 4759.00, 1, 16, '2025-06-02 19:51:50', 'prod_683e00d67243d9.63251562.png', NULL),
(24, 'Samsung Galaxy 24 ultra', 'mobile', '6.8\" AMOLED 120Hz, 3120×1440, Snapdragon 8 Gen 3, 12GB RAM, 256/512GB/1TB, 200MP quad cam, 12MP front, 5000mAh, 45W, S Pen, Android 14, Titanium body', 70990.00, 1, 9, '2025-06-02 19:53:26', 'prod_683e0136d4bce7.11618965.png', NULL),
(25, 'iPhone 16 Pro', 'mobile', '6.3\" Super Retina XDR OLED, 2622×1206, 120Hz ProMotion, HDR10, Dolby Vision, Apple A18 Pro\r\n', 70359.00, 1, 9, '2025-06-02 19:54:47', 'prod_683e0187d17181.59294895.png', NULL),
(26, 'NVIDIA GeForce GTX 1070', 'component', 'minted', 8499.00, 1, 19, '2025-06-02 19:56:43', 'prod_683e01fb868331.95456396.png', NULL),
(27, 'MacBook Pro', 'desktop', '13.3\" Retina display, Apple M2 chip, 8–24GB RAM, 256GB–2TB SSD, up to 20h battery life, 2 Thunderbolt 4 ports, macOS Sonoma', 101990.00, 1, 7, '2025-06-02 19:58:41', 'prod_683e02716ec0d1.66525104.png', NULL),
(28, 'DJI Osmo Mobile SE', 'others', '3-axis smartphone gimbal, Portrait & landscape, Up to 15 hours', 3600.00, 1, 13, '2025-06-02 20:00:05', 'prod_683e02c57e7992.18070666.png', NULL),
(29, 'de3', 'component', 'd3d32', 34.00, 1, 3, '2025-06-03 00:22:29', '683e4045abc04.png', NULL),
(30, 'wsdfcwef', 'others', 'wefwef', 32423.00, 1, 3, '2025-06-03 00:24:15', '683e40af9f207.jpg', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `transaction_history`
--

CREATE TABLE `transaction_history` (
  `transaction_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `transaction_date` datetime NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'Completed'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transaction_history`
--

INSERT INTO `transaction_history` (`transaction_id`, `user_id`, `product_id`, `seller_id`, `quantity`, `total_price`, `payment_method`, `transaction_date`, `status`) VALUES
(12, 3, 27, 1, 1, 101990.00, 'gcash', '2025-06-02 22:02:01', 'Completed'),
(13, 3, 16, 1, 1, 69995.00, 'gcash', '2025-06-02 22:02:01', 'Completed'),
(14, 3, 18, 1, 1, 54845.00, 'gcash', '2025-06-02 22:02:01', 'Completed'),
(15, 3, 16, 1, 1, 69995.00, 'gcash', '2025-06-02 22:29:36', 'Completed'),
(16, 3, 26, 1, 1, 8499.00, 'gcash', '2025-06-02 22:29:36', 'Completed'),
(17, 3, 27, 1, 1, 101990.00, 'gcash', '2025-06-02 22:29:36', 'Completed'),
(18, 3, 19, 1, 1, 2995.00, 'gcash', '2025-06-02 22:37:56', 'Completed'),
(19, 3, 20, 1, 1, 3195.00, 'gcash', '2025-06-02 22:41:28', 'Completed'),
(20, 3, 19, 1, 1, 2995.00, 'gcash', '2025-06-02 22:45:26', 'Completed'),
(21, 3, 18, 1, 1, 54845.00, 'gcash', '2025-06-02 22:47:18', 'Completed'),
(22, 3, 27, 1, 1, 101990.00, 'gcash', '2025-06-02 22:48:15', 'Completed'),
(23, 3, 28, 1, 1, 3600.00, 'gcash', '2025-06-02 22:51:18', 'Completed'),
(24, 3, 20, 1, 1, 3195.00, 'gcash', '2025-06-02 23:01:37', 'Completed'),
(25, 3, 18, 1, 1, 54845.00, 'gcash', '2025-06-02 23:06:52', 'Completed'),
(26, 3, 17, 1, 1, 31990.00, 'gcash', '2025-06-02 23:12:13', 'Completed'),
(27, 3, 18, 1, 1, 54845.00, 'gcash', '2025-06-02 23:17:47', 'Completed'),
(28, 3, 23, 1, 1, 4759.00, 'gcash', '2025-06-02 23:22:51', 'Completed'),
(29, 3, 25, 1, 1, 70359.00, 'gcash', '2025-06-02 23:39:06', 'Completed'),
(30, 1, 20, 1, 1, 3195.00, 'gcash', '2025-06-02 23:54:59', 'Completed'),
(31, 4, 18, 1, 1, 54845.00, 'gcash', '2025-06-03 00:21:25', 'Completed'),
(32, 3, 22, 1, 1, 10773.00, 'gcash', '2025-06-03 00:39:28', 'Completed'),
(33, 3, 24, 1, 1, 70990.00, 'gcash', '2025-06-03 00:53:02', 'Completed'),
(34, 3, 28, 1, 1, 3600.00, 'gcash', '2025-06-03 01:51:37', 'Completed'),
(35, 3, 23, 1, 1, 4759.00, 'paypal', '2025-06-03 01:52:23', 'Completed'),
(36, 6, 30, 1, 2, 64846.00, 'gcash', '2025-06-03 02:26:42', 'Completed'),
(37, 6, 21, 1, 2, 6390.00, 'gcash', '2025-06-03 02:26:42', 'Completed'),
(38, 6, 23, 1, 2, 9518.00, 'gcash', '2025-06-03 02:26:42', 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','customer','seller') NOT NULL DEFAULT 'customer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(1, 'admin', '$2y$10$RlQcgsVWVlt7YrXXwTQ3YOpzj1I2iGlPIGFTfQr2IJlKmvBoiATKu', 'admin'),
(3, 'john', '$2y$10$GxT6rvr5tnX.bPtGG2DCmOIjoEqtyqpmzfQ6Pi75V/2oDb//QQD2u', 'customer'),
(4, 'joaquin', '$2y$10$Y9i14Ow88ZA0LjEQ7a1akOVUDxTnIc3NaGvyxaSwn1aMY0Guw116y', 'customer'),
(5, 'marc', '$2y$10$lP125sc6w.CWjAtR47YneeSZirRKEj249NJio8EanzPXLhjbtkA9C', 'customer'),
(6, 'juan', '$2y$10$miyjq7VW6CpLGuFlbPl36Or1fnMhnKwk0YTC.BZGBki.mMfwx4ePe', 'customer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction_history`
--
ALTER TABLE `transaction_history`
  ADD PRIMARY KEY (`transaction_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `seller_id` (`seller_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `transaction_history`
--
ALTER TABLE `transaction_history`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `transaction_history`
--
ALTER TABLE `transaction_history`
  ADD CONSTRAINT `transaction_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `transaction_history_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `transaction_history_ibfk_3` FOREIGN KEY (`seller_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
