<?php
echo password_hash("adminpassword", PASSWORD_DEFAULT);
?>
