<?php
session_start();
header('Content-Type: application/json');
include '../db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$seller_id = $_SESSION['user_id'];

$name = $_POST['name'] ?? '';
$category = $_POST['category'] ?? '';
$description = $_POST['description'] ?? '';
$price = floatval($_POST['price'] ?? 0);
$stock = intval($_POST['stock'] ?? 0);

// Validate inputs (simplified)
if (!$name || !$category || !$description || $price < 0 || $stock < 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit();
}

// Handle image upload
if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'message' => 'Image upload failed']);
    exit();
}

$image = $_FILES['image'];
$upload_dir = 'uploads/product/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

$image_ext = pathinfo($image['name'], PATHINFO_EXTENSION);
$allowed_exts = ['jpg', 'jpeg', 'png', 'gif'];
if (!in_array(strtolower($image_ext), $allowed_exts)) {
    echo json_encode(['success' => false, 'message' => 'Invalid image type']);
    exit();
}

$image_path = uniqid() . '.' . $image_ext;
$target_path = $upload_dir . $image_path;

if (!move_uploaded_file($image['tmp_name'], $target_path)) {
    echo json_encode(['success' => false, 'message' => 'Failed to save image']);
    exit();
}

// Insert product
$stmt = $conn->prepare("INSERT INTO products (seller_id, name, category, description, price, stock, image_path) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("isssdis", $seller_id, $name, $category, $description, $price, $stock, $image_path);
if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => 'Database error']);
}
exit();
?>
