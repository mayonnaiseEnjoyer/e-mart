<?php
session_start();
header('Content-Type: application/json');
include '../db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false]);
    exit();
}

$seller_id = $_SESSION['user_id'];
$product_id = intval($_POST['product_id'] ?? 0);

if ($product_id <= 0) {
    echo json_encode(['success' => false]);
    exit();
}

// Ensure the product belongs to the seller
$stmt = $conn->prepare("SELECT image_path FROM products WHERE id = ? AND seller_id = ?");
$stmt->bind_param("ii", $product_id, $seller_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    echo json_encode(['success' => false]);
    exit();
}

$product = $result->fetch_assoc();
$image_path = $product['image_path'];

// Delete product
$del_stmt = $conn->prepare("DELETE FROM products WHERE id = ? AND seller_id = ?");
$del_stmt->bind_param("ii", $product_id, $seller_id);
if ($del_stmt->execute()) {
    // Delete image file
    $file_path = 'uploads/product/' . $image_path;
    if (file_exists($file_path)) {
        unlink($file_path);
    }
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false]);
}
exit();
?>
