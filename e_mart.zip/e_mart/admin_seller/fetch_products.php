<?php
// fetch_products.php

header('Content-Type: application/json');

include '../db_connect.php';  // Adjust path as needed

$sql = "SELECT id, name, category, description, price, stock, image_path FROM products ORDER BY created_at DESC";
$result = $conn->query($sql);

$products = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
}

echo json_encode($products);
?>
