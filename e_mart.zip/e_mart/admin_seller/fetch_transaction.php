<?php
session_start();
header('Content-Type: application/json');

include '../db_connect.php';  // Adjust the path if needed

// Check if user is logged in and is a seller
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] !== 'seller') {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$seller_id = $_SESSION['user_id'];

// Get total earnings for this seller
$stmt = $conn->prepare("SELECT IFNULL(SUM(total_price), 0) as total_earnings FROM transaction_history WHERE seller_id = ?");
$stmt->bind_param('i', $seller_id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$total_earnings = $row['total_earnings'] ?? 0;

// Get transaction history for this seller with buyer & product names
$stmt = $conn->prepare("
    SELECT th.transaction_id, u.username AS buyer_name, p.name AS product_name,
           th.quantity, th.total_price, th.payment_method, th.transaction_date, th.status
    FROM transaction_history th
    JOIN users u ON th.user_id = u.id
    JOIN products p ON th.product_id = p.id
    WHERE th.seller_id = ?
    ORDER BY th.transaction_date DESC
");
$stmt->bind_param('i', $seller_id);
$stmt->execute();
$result = $stmt->get_result();

$transactions = [];
while ($tx = $result->fetch_assoc()) {
    $transactions[] = $tx;
}

echo json_encode([
    'total_earnings' => (float)$total_earnings,
    'transactions' => $transactions
]);
    