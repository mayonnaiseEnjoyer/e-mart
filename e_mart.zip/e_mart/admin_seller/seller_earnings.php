<?php
session_start();
header('Content-Type: application/json');
include '../db_connect.php'; // adjust path if needed

// Check if seller is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'seller') {
    echo json_encode([]); // return empty array if not authorized
    exit();
}

$seller_id = $_SESSION['user_id'];

$transactions_query = $conn->prepare("
    SELECT 
        th.transaction_id,
        u.username AS buyer_name,
        p.name AS product_name,
        th.quantity,
        th.total_price,
        th.payment_method,
        th.transaction_date
    FROM 
        transaction_history th
    JOIN 
        users u ON th.user_id = u.id
    JOIN 
        products p ON th.product_id = p.id
    WHERE 
        th.seller_id = ?
    ORDER BY 
        th.transaction_date DESC
");

$transactions_query->bind_param("i", $seller_id);
$transactions_query->execute();
$transactions_result = $transactions_query->get_result();

$transactions = [];

while ($row = $transactions_result->fetch_assoc()) {
    $transactions[] = [
        'transaction_id' => $row['transaction_id'],
        'buyer_name' => $row['buyer_name'],
        'product_name' => $row['product_name'],
        'quantity' => (int)$row['quantity'],
        'total_price' => (float)$row['total_price'],
        'payment_method' => $row['payment_method'],
        'transaction_date' => $row['transaction_date']
    ];
}

echo json_encode($transactions);
exit();
?>
