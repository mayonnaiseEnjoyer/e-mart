<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Guest';

// Include DB connection
if (file_exists('../db_connect.php')) {
    include '../db_connect.php';
} elseif (file_exists('db_connect.php')) {
    include 'db_connect.php';
} elseif (file_exists('../../db_connect.php')) {
    include '../../db_connect.php';
} else {
    die("Database connection file not found.");
}

// Default earnings and transactions
$total_earnings = 0;
$transactions = [];

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $user_role = $_SESSION['role'] ?? '';

    if ($user_role === 'admin' || $user_role === 'seller') {
        $seller_id = $user_id;

        // Earnings
        $stmt = $conn->prepare("SELECT IFNULL(SUM(total_price), 0) as total_earnings FROM transaction_history WHERE seller_id = ?");
        $stmt->bind_param('i', $seller_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        $total_earnings = $row['total_earnings'] ?? 0;

        // Transactions
        $stmt = $conn->prepare("
            SELECT th.transaction_id, u.username AS buyer_name, p.name AS product_name,
                   th.quantity, th.total_price, th.payment_method, th.transaction_date, th.status
            FROM transaction_history th
            JOIN users u ON th.user_id = u.id
            JOIN products p ON th.product_id = p.id
            WHERE th.seller_id = ?
            ORDER BY th.transaction_date DESC
            LIMIT 50
        ");
        $stmt->bind_param('i', $seller_id);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($tx = $result->fetch_assoc()) {
            $transactions[] = $tx;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Seller Dashboard</title>
  <link rel="stylesheet" href="admin_seller_screen_style.css" />
  <style>               
  </style>
</head>
<body>
  <div class="dashboard-container">
    <header class="header">
      <h1>Seller Dashboard</h1>
<p class="username">Logged in as: <strong><?php echo htmlspecialchars($username); ?></strong></p>

<form action="../index.html" method="post" style="display: inline-block; margin-left: 10px;">
  <button type="submit" class="logout-btn">Logout</button>
</form>

    </header>

    <div class="main-content" style="display: flex; gap: 30px; flex-wrap: wrap;">
      <!-- LEFT SIDE -->
      <div style="flex: 3; min-width: 300px;">
        <section class="products-section">
          <h2>Your Products</h2>
          <div class="products-list" id="products-list"></div>
          <button class="add-product-button" id="add-product-btn">Add New Product</button>
        </section>

        <section class="transactions-section">
          <h2>Transaction History</h2>
          <div class="transactions-list" id="transactions-list">
            <?php if (empty($transactions)): ?>
              <p>No transaction history.</p>
            <?php else: ?>
              <?php foreach ($transactions as $tx): ?>
                <div class="delivery-item" style="background-color: #27272b; color: #ffffff;">
                  <p><strong>Order #<?= $tx['transaction_id'] ?></strong></p>
                  <p>Status: <span class="status"><?= htmlspecialchars($tx['status']) ?></span></p>
                  <p>Product: <?= htmlspecialchars($tx['product_name']) ?></p>
                  <p>Buyer: <?= htmlspecialchars($tx['buyer_name']) ?></p>
                  <p>Quantity: <?= (int)$tx['quantity'] ?></p>
                  <p>Total Paid: ₱<?= number_format((float)$tx['total_price'], 2) ?></p>
                  <p>Payment: <?= htmlspecialchars($tx['payment_method']) ?></p>
                  <p>Date: <?= date('Y-m-d H:i:s', strtotime($tx['transaction_date'])) ?></p>
                </div>
              <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </section>
      </div>

      <!-- RIGHT SIDE -->
      <div style="flex: 1; min-width: 250px;">
        <section class="earnings-section">
          <h2>Total Earnings</h2>
          <div class="earnings-display" id="earnings-display">
            ₱<span id="total-earnings"><?= number_format((float)$total_earnings, 2) ?></span>
          </div>
        </section>
      </div>
    </div>
  </div>

  <!-- Add Product Modal -->
  <div class="modal" id="addProductModal" style="display:none;">
    <div class="modal-content">
      <span class="close" id="closeModal">&times;</span>
      <h2>Add New Product</h2>
      <form id="addProductForm" enctype="multipart/form-data">
        <label for="productName">Name:</label>
        <input type="text" id="productName" name="name" required />
        <label for="productCategory">Category:</label>
        <select id="productCategory" name="category" required>
          <option value="">Select category</option>
          <option value="desktop">Desktop</option>
          <option value="mobile">Mobile</option>
          <option value="component">Component</option>
          <option value="peripheral">Peripheral</option>
          <option value="gaming">Gaming</option>
          <option value="others">Others</option>
        </select>
        <label for="productDescription">Description:</label>
        <textarea id="productDescription" name="description" rows="3" required></textarea>
        <label for="productPrice">Price:</label>
        <input type="number" id="productPrice" name="price" step="0.01" min="0" required />
        <label for="productStock">Stock:</label>
        <input type="number" id="productStock" name="stock" min="0" required />
        <label for="productImage">Image:</label>
        <input type="file" id="productImage" name="image" accept="image/*" required />
        <button type="submit">Add Product</button>
      </form>
      <div id="formMessage"></div>
    </div>
  </div>

  <script>
    const addProductBtn = document.getElementById('add-product-btn');
    const modal = document.getElementById('addProductModal');
    const closeModalBtn = document.getElementById('closeModal');
    const addProductForm = document.getElementById('addProductForm');
    const formMessage = document.getElementById('formMessage');
    const productsListDiv = document.getElementById('products-list');

    addProductBtn.addEventListener('click', () => {
      formMessage.innerText = '';
      addProductForm.reset();
      modal.style.display = 'block';
    });

    closeModalBtn.addEventListener('click', () => {
      modal.style.display = 'none';
    });

    window.onclick = function (event) {
      if (event.target == modal) {
        modal.style.display = 'none';
      }
    };

    function loadProducts() {
      fetch('fetch_products.php')
        .then(res => res.json())
        .then(products => {
          productsListDiv.innerHTML = '';
          if (products.length === 0) {
            productsListDiv.innerHTML = '<p>No products found.</p>';
            return;
          }
          products.forEach(product => {
            const div = document.createElement('div');
            div.classList.add('product-item');
            div.innerHTML = `
              <img src="uploads/product/${product.image_path}" alt="${product.name}" />
              <div class="product-info">
                <p class="product-name">${product.name}</p>
                <p class="product-description">${product.description}</p>
                <p class="product-price">₱${parseFloat(product.price).toFixed(2)}</p>
                <p class="product-stock">Stock: ${product.stock}</p>
                <button class="delete-btn" data-id="${product.id}">remove</button>
              </div>`;
            div.querySelector('.delete-btn').addEventListener('click', () => {
              if (confirm(`Delete "${product.name}"?`)) {
                fetch('delete_product.php', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                  body: `product_id=${product.id}`
                })
                .then(res => res.json())
                .then(data => {
                  if (data.success) {
                    alert('Product deleted.');
                    loadProducts();
                  } else {
                    alert('Failed to delete.');
                  }
                });
              }
            });
            productsListDiv.appendChild(div);
          });
        });
    }

    addProductForm.addEventListener('submit', e => {
      e.preventDefault();
      const formData = new FormData(addProductForm);
      fetch('add_product.php', {
        method: 'POST',
        body: formData
      })
      .then(res => res.json())
      .then(data => {
        if (data.success) {
          formMessage.style.color = 'lightgreen';
          formMessage.innerText = 'Product added!';
          addProductForm.reset();
          loadProducts();
          setTimeout(() => modal.style.display = 'none', 1500);
        } else {
          formMessage.style.color = 'red';
          formMessage.innerText = data.message || 'Failed to add.';
        }
      });
    });

    loadProducts();
  </script>
</body>
</html>
