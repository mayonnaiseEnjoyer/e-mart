<?php
session_start();

header('Content-Type: application/json');

$username = $_SESSION['username'] ?? '';

if (!$username) {
    echo json_encode(['error' => 'User not logged in']);
    exit;
}

try {
    $pdo = new PDO('mysql:host=localhost;dbname=e_mart', 'john', 'johnpassword');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get seller id from username
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = :username LIMIT 1");
    $stmt->execute(['username' => $username]);
    $seller = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$seller) {
        echo json_encode(['error' => 'Seller not found']);
        exit;
    }

    $seller_id = $seller['id'];

    // Query total earnings
    $stmtSum = $pdo->prepare("SELECT SUM(total_price) AS total_earnings FROM transaction_history WHERE seller_id = :seller_id");
    $stmtSum->execute(['seller_id' => $seller_id]);
    $totalEarnings = $stmtSum->fetchColumn();

    echo json_encode(['total_earnings' => $totalEarnings ?: 0]);
} catch (PDOException $e) {
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
