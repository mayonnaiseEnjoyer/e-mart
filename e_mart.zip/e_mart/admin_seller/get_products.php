<?php
// get_products.php
header('Content-Type: application/json');

include '../db_connect.php'; // adjust path to your DB connection file

$sql = "SELECT id, name, description, price, stock, image_path FROM products ORDER BY created_at DESC";
$result = $conn->query($sql);

$products = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
}

echo json_encode($products);
